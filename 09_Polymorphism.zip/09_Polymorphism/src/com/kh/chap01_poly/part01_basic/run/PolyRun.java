package com.kh.chap01_poly.part01_basic.run;

import com.kh.chap01_poly.part01_basic.model.vo.*;

public class PolyRun {

	public static void main(String[] args) {
		
		/*
		 * 명심할 사항 : '=' 대입연산자 기준으로 왼쪽과 오른쪽의 자료형은 "항상" 같아야함
		 * 
		 *  1. 부모타입 레퍼런스 변수로 부모타입 객체를 다루는것 => 당연히 가능하다
		 */
		System.out.println("1. 부모타입 레퍼런스변수로 부모객체를 다루는 경우");
		Parent p1 = new Parent();
		p1.printParent();
		// p1레퍼런스변수로 Parent에만 접근가능
		
		// 2. 자식타입 레퍼런스 	변수로 자식 객체를 다루는 경우
	}

}
